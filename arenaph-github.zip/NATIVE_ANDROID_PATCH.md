# ArenaPH native app: one small addition for "game-only video"

The web code now works inside your Android app without changes: detection reads the text your native reader
already sends (`window.__nStats`), starts the reader automatically when the live starts, and tells viewers to show a
"Broadcast Break" card whenever you are not in a match.

To also STOP the video leaving the phone (not only hide it on viewers' screens), add this to your existing
`AndroidLive` JavaScript interface class. Use the name of the screen-capture VideoTrack you already create for WebRTC.

```kotlin
@JavascriptInterface
fun setVideoEnabled(on: Boolean) {
    // videoTrack = the org.webrtc.VideoTrack made from your ScreenCapturer
    activity.runOnUiThread { videoTrack?.setEnabled(on) }
}
```

Until this is added the app shows "⚠ update app" in the broadcast status chip and relies on the viewer-side cover.
Optional: also add a similar `setAudioEnabled(on: Boolean)` using your audio track if you want game audio muted outside matches.

package ph.arena.app;
import android.app.*;import android.content.Intent;import android.content.pm.ServiceInfo;import android.os.Build;import android.os.IBinder;
public class ScreenService extends Service {
  static Runnable onReady;
  @Override public IBinder onBind(Intent i){return null;}
  @Override public int onStartCommand(Intent i,int f,int id){
    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("live","Live",NotificationManager.IMPORTANCE_LOW));
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"live"):new Notification.Builder(this);
    Notification n=b.setContentTitle("ArenaPH is live").setContentText("Sharing your screen").setSmallIcon(android.R.drawable.presence_video_online).build();
    if(Build.VERSION.SDK_INT>=29)startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(1,n);
    Runnable r=onReady;onReady=null;if(r!=null)r.run();
    return START_NOT_STICKY;}
}

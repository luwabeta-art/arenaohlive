package ph.arena.app;
import android.Manifest;import android.app.Activity;import android.content.Intent;import android.content.pm.PackageManager;import android.graphics.Color;import android.media.projection.MediaProjectionManager;import android.net.Uri;import android.os.Build;import android.os.Bundle;import android.util.DisplayMetrics;import android.view.View;import android.view.ViewGroup;import android.webkit.*;import android.widget.FrameLayout;
import androidx.webkit.WebViewAssetLoader;
import org.json.*;import org.webrtc.*;import java.util.*;

public class MainActivity extends Activity {
  // >>> PUT YOUR HOSTED LINK HERE (the https page that serves your latest index.html, e.g. your GitHub Pages or Cloudflare Pages link) <<<
  static final String REMOTE_URL="https://YOUR-USERNAME.github.io/YOUR-REPO/index.html";
  static final String LOCAL_URL="https://appassets.androidplatform.net/assets/index.html";
  boolean usedFallback=false;
  WebView web;FrameLayout root;View custom;WebChromeClient.CustomViewCallback customCb;
  PeerConnectionFactory factory;EglBase egl;VideoCapturer capturer;SurfaceTextureHelper helper;VideoSource vsrc;AudioSource asrc;VideoTrack vt;AudioTrack at;
  final Map<String,PeerConnection> pcs=new HashMap<>();List<PeerConnection.IceServer> ice=new ArrayList<>();
  Intent projData;PermissionRequest pendingPerm;

  @Override protected void onCreate(Bundle b){super.onCreate(b);
    root=new FrameLayout(this);root.setBackgroundColor(Color.parseColor("#100e0d"));setContentView(root);
    if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS,Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},1);
    else requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},1);
    web=new WebView(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);s.setJavaScriptCanOpenWindowsAutomatically(true);s.setSupportMultipleWindows(false);s.setCacheMode(WebSettings.LOAD_DEFAULT);
    CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
    final WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
    web.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return loader.shouldInterceptRequest(r.getUrl());}
      @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){
        if(r.isForMainFrame()&&!usedFallback&&!r.getUrl().toString().startsWith(LOCAL_URL)){usedFallback=true;v.loadUrl(LOCAL_URL);}}
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){if(!r.isForMainFrame())return false;Uri u=r.getUrl();String h=u.getHost()==null?"":u.getHost();
        if(h.equals("appassets.androidplatform.net")||h.equals(remoteHost()))return false;
        try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){}return true;}});
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onPermissionRequest(final PermissionRequest r){runOnUiThread(()->r.grant(r.getResources()));}
      @Override public void onShowCustomView(View v,CustomViewCallback cb){custom=v;customCb=cb;root.addView(v,new FrameLayout.LayoutParams(-1,-1));web.setVisibility(View.GONE);
        v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
      @Override public void onHideCustomView(){if(custom==null)return;root.removeView(custom);custom=null;web.setVisibility(View.VISIBLE);if(customCb!=null)customCb.onCustomViewHidden();}
    });
    web.addJavascriptInterface(new Bridge(),"AndroidLive");
    if(remoteOk())web.loadUrl(REMOTE_URL+(REMOTE_URL.contains("?")?"&":"?")+"_="+System.currentTimeMillis());else web.loadUrl(LOCAL_URL);}

  static boolean remoteOk(){return REMOTE_URL.startsWith("https://")&&!REMOTE_URL.contains("YOUR-");}
  static String remoteHost(){try{return remoteOk()?Uri.parse(REMOTE_URL).getHost():"";}catch(Exception e){return "";}}

  @Override public void onBackPressed(){if(custom!=null){web.getWebChromeClient().onHideCustomView();return;}if(web.canGoBack())web.goBack();else moveTaskToBack(true);}
  @Override protected void onDestroy(){stopAll();super.onDestroy();}

  void js(final String code){runOnUiThread(()->web.evaluateJavascript(code,null));}
  void initFactory(){if(factory!=null)return;
    PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(getApplicationContext()).createInitializationOptions());
    egl=EglBase.create();
    factory=PeerConnectionFactory.builder().setVideoEncoderFactory(new DefaultVideoEncoderFactory(egl.getEglBaseContext(),true,true)).setVideoDecoderFactory(new DefaultVideoDecoderFactory(egl.getEglBaseContext())).createPeerConnectionFactory();}

  @Override protected void onActivityResult(int rq,int rs,Intent d){super.onActivityResult(rq,rs,d);
    if(rq!=42)return;
    if(rs!=RESULT_OK||d==null){js("window.__nScreen&&__nScreen(false,'Screen capture was cancelled. Tap Start now to allow it.')");return;}
    projData=d;
    ScreenService.onReady=()->runOnUiThread(this::beginCapture);
    Intent si=new Intent(this,ScreenService.class);
    if(Build.VERSION.SDK_INT>=26)startForegroundService(si);else startService(si);}

  void beginCapture(){
    try{initFactory();
      capturer=new ScreenCapturerAndroid(projData,new android.media.projection.MediaProjection.Callback(){@Override public void onStop(){stopAll();js("window.__nStop&&__nStop()");}});
      helper=SurfaceTextureHelper.create("cap",egl.getEglBaseContext());
      vsrc=factory.createVideoSource(true);capturer.initialize(helper,getApplicationContext(),vsrc.getCapturerObserver());
      DisplayMetrics m=getResources().getDisplayMetrics();int w=720,h=Math.round(720f*Math.max(m.widthPixels,m.heightPixels)/Math.min(m.widthPixels,m.heightPixels));h-=h%2;
      boolean land=m.widthPixels>m.heightPixels;capturer.startCapture(land?h:w,land?w:h,30);
      vt=factory.createVideoTrack("v0",vsrc);
      asrc=factory.createAudioSource(new MediaConstraints());at=factory.createAudioTrack("a0",asrc);
      js("window.__nScreen&&__nScreen(true,'')");
    }catch(Throwable e){stopAll();js("window.__nScreen&&__nScreen(false,"+JSONObject.quote(String.valueOf(e))+")");}}

  void stopAll(){
    for(PeerConnection p:new ArrayList<>(pcs.values())){try{p.close();}catch(Exception e){}}pcs.clear();
    try{if(capturer!=null){capturer.stopCapture();capturer.dispose();}}catch(Exception e){}capturer=null;
    try{if(vt!=null)vt.dispose();if(at!=null)at.dispose();if(vsrc!=null)vsrc.dispose();if(asrc!=null)asrc.dispose();if(helper!=null)helper.dispose();}catch(Exception e){}
    vt=null;at=null;vsrc=null;asrc=null;helper=null;
    try{stopService(new Intent(this,ScreenService.class));}catch(Exception e){}}

  class Bridge{
    @JavascriptInterface public void startScreen(boolean mic){runOnUiThread(()->{try{
      MediaProjectionManager mp=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(mp.createScreenCaptureIntent(),42);
    }catch(Throwable e){js("window.__nScreen&&__nScreen(false,"+JSONObject.quote(String.valueOf(e))+")");}});}
    @JavascriptInterface public void stopScreen(){runOnUiThread(MainActivity.this::stopAll);}
    @JavascriptInterface public void setMic(boolean on){runOnUiThread(()->{if(at!=null)at.setEnabled(on);});}
    @JavascriptInterface public void setIce(String json){try{JSONArray a=new JSONArray(json);List<PeerConnection.IceServer> l=new ArrayList<>();
      for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);List<String> urls=new ArrayList<>();Object u=o.opt("urls");if(u==null)u=o.opt("url");
        if(u instanceof JSONArray){for(int k=0;k<((JSONArray)u).length();k++)urls.add(((JSONArray)u).getString(k));}else if(u!=null)urls.add(String.valueOf(u));
        if(urls.isEmpty())continue;PeerConnection.IceServer.Builder b=PeerConnection.IceServer.builder(urls);
        if(o.has("username"))b.setUsername(o.getString("username"));if(o.has("credential"))b.setPassword(o.getString("credential"));l.add(b.createIceServer());}
      if(!l.isEmpty())ice=l;}catch(Exception e){}}
    @JavascriptInterface public void offer(final String vid){runOnUiThread(()->{try{
      if(factory==null||vt==null)return;
      PeerConnection old=pcs.remove(vid);if(old!=null)old.close();
      List<PeerConnection.IceServer> l=ice.isEmpty()?Arrays.asList(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()):ice;
      PeerConnection.RTCConfiguration c=new PeerConnection.RTCConfiguration(l);c.sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;
      final PeerConnection pc=factory.createPeerConnection(c,new PeerConnection.Observer(){
        public void onIceCandidate(IceCandidate x){try{JSONObject o=new JSONObject();o.put("candidate",x.sdp);o.put("sdpMid",x.sdpMid);o.put("sdpMLineIndex",x.sdpMLineIndex);js("window.__nIce&&__nIce("+JSONObject.quote(vid)+","+JSONObject.quote(o.toString())+")");}catch(Exception e){}}
        public void onConnectionChange(PeerConnection.PeerConnectionState s){js("window.__nConn&&__nConn("+JSONObject.quote(vid)+","+JSONObject.quote(s.name().toLowerCase())+")");}
        public void onSignalingChange(PeerConnection.SignalingState s){}public void onIceConnectionChange(PeerConnection.IceConnectionState s){}public void onIceConnectionReceivingChange(boolean b){}
        public void onIceGatheringChange(PeerConnection.IceGatheringState s){}public void onIceCandidatesRemoved(IceCandidate[] x){}public void onAddStream(MediaStream m){}public void onRemoveStream(MediaStream m){}
        public void onDataChannel(DataChannel d){}public void onRenegotiationNeeded(){}public void onAddTrack(RtpReceiver r,MediaStream[] m){}});
      if(pc==null)return;pcs.put(vid,pc);
      pc.addTrack(vt,Collections.singletonList("s0"));if(at!=null)pc.addTrack(at,Collections.singletonList("s0"));
      pc.createOffer(new SdpObserver(){
        public void onCreateSuccess(final SessionDescription d){pc.setLocalDescription(new SdpObserver(){public void onCreateSuccess(SessionDescription x){}public void onSetSuccess(){
          js("window.__nOffer&&__nOffer("+JSONObject.quote(vid)+","+JSONObject.quote(d.type.canonicalForm())+","+JSONObject.quote(d.description)+")");}public void onCreateFailure(String e){}public void onSetFailure(String e){}},d);}
        public void onSetSuccess(){}public void onCreateFailure(String e){}public void onSetFailure(String e){}},new MediaConstraints());
    }catch(Throwable e){}});}
    @JavascriptInterface public void answer(final String vid,final String type,final String sdp){runOnUiThread(()->{PeerConnection pc=pcs.get(vid);if(pc==null)return;
      pc.setRemoteDescription(new SdpObserver(){public void onCreateSuccess(SessionDescription x){}public void onSetSuccess(){}public void onCreateFailure(String e){}public void onSetFailure(String e){}},new SessionDescription(SessionDescription.Type.fromCanonicalForm(type),sdp));});}
    @JavascriptInterface public void ice(final String vid,final String json){runOnUiThread(()->{try{PeerConnection pc=pcs.get(vid);if(pc==null)return;JSONObject o=new JSONObject(json);
      pc.addIceCandidate(new IceCandidate(o.optString("sdpMid",null),o.optInt("sdpMLineIndex",0),o.getString("candidate")));}catch(Exception e){}});}
    @JavascriptInterface public void drop(final String vid){runOnUiThread(()->{PeerConnection pc=pcs.remove(vid);if(pc!=null)try{pc.close();}catch(Exception e){}});}
  }
}
